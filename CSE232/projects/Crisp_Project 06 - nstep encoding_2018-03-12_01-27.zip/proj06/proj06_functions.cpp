//AUTHOR:   DAN CRISP
//DATE:     March11, 2018
//CLASS:    CSE232, Section 730
/* description
    fibinacci sequences of n seeded numbers are used
    long inputs are encoded as a binary string, relative to indices of a given sequence
    alternatively, a binary string is decoded with a user specified fibinacci sequence
*/

#include<iostream>
using std::cout; using std::endl;
#include<string>
using std::string; using std::to_string;
#include<vector>
using std::vector;

#include "proj06_functions.h"


//take a vector of longs, convert it to a string
string vec_2_str(const vector<long>& v){
    string str;
    
    for( auto ele : v ){
        str = str + to_string(ele);
        str.push_back(',');
    }
    
    str = str.substr(0, str.size()-1); //Remove last ','
    
    return str;
};


//generate an nstep vector of longs (aka a fibinacci seq.), based on given high number limit, and the number of seed values.
vector<long> gen_nstep_vector (long limit, long nstep){
    vector<long> seq;
    long tmp;
    
    //generate first nstep seeds, with 0th = 1
    seq.push_back(1);
    seq.push_back(1);
    for(int i = 2; i < nstep; i++){
        seq.push_back(0);
        
        for(size_t j = 0; j < seq.size()-1; j++){
            seq[i] = seq[i] + seq[j];
        }
    }
    
    //generate remaining numbers based on last nstep values up to given limit
    do{
        tmp = 0;
        for(size_t i = seq.size()-nstep; i < seq.size(); i++){
            tmp = tmp + seq[i];
        }
        
        if(tmp <= limit){
            seq.push_back(tmp);
        }
        
    }while(tmp <= limit);
    
    return seq;
};


//generate a binary string from a fibinacci sequence with largest value under num, and nstep seed values.
string num_to_nstep_coding(long num, long nstep){
    vector<long> seq = gen_nstep_vector(num, nstep);
    
    //initiate binary string to appropriate length
    string str (seq.size()-1, '0');
    
    //set 1 values in binary string, based on largest seq. values under num
    for (size_t indx = seq.size(); indx > 0; indx--){
        if(seq[indx] <= num){
            str[indx-1] = '1';
            num = num - seq[indx];
        }
        if(num == 0) return str;
    }
    
    return str;
};


//given a binary string, and a fib. seq., decode the string to return a number
long nstep_coding_to_num(const string& coding, const vector<long>& nstep_sequence){
    long num = 0;
    
    for(size_t indx = 0; indx <= nstep_sequence.size(); indx++){
        
        if(coding[indx]=='1'){
            num = num + nstep_sequence[indx+1];
        }
    }
    
    return num;
};