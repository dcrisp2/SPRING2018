#include<iostream>
using std::cout; using std::endl; using std::cin; using std::boolalpha; using std::ostream;
#include<vector>
using std::vector;
#include<string>
using std::string;
#include "proj06_functions.h"

int main(){
    /*vector<long>v{1,2,3,4,5};
    string s = vec_2_str(v);
    
    for(auto ele : s){
        cout << ele;
    }
    cout << endl;
    string ans = "1,2,3,4,5";*/
    
    
    /*vector<long>v = gen_nstep_vector(100, 2);
    for(auto ele : v){
        cout << ele << ",";
    }
    cout << endl;
    vector<long> ans{1,1,2,3,5,8,13,21,34,55,89};*/
    
    /*vector<long>v = gen_nstep_vector(976, 6);
    for(auto ele : v){
        cout << ele << ",";
    }
    cout << endl;
    vector<long> ans{1,1,2,4,8,16,32,63,125,248,492,976};
        for(auto ele : ans){
        cout << ele << ",";
    }
    cout << endl;*/
    
    /*string s = num_to_nstep_coding(100,2);
    cout << s << endl;
    string ans = "0010100001";*/
    
    vector<long> v = gen_nstep_vector(1794,5);
    //string s = "0010100001";
    string s = "100000000001";
    long l = nstep_coding_to_num(s,v);
    cout << "l is:" << l << endl;
    long ans = 1794;
    cout << "l should be:" << ans << endl;
    
    return 0;
}