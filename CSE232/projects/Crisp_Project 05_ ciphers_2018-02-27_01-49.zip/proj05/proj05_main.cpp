#include<iostream>
using std::cout; using std::endl; using std::cin; using std::boolalpha; using std::ostream;

#include<string>
using std::string; using std::getline;

#include<vector>
using std::vector;

#include "proj05_functions.h"

int main(){
	//int select;
	//string msg = "hello world";
	//string msg = "example"
	
	/*cout << "msg Length:" << msg.length()
		<< "\nmsg Length%2:" << msg.length()%2
		<< endl;
	
	
	std::string::iterator i = msg.begin()+2;
	cout << "msg dist:" << distance(msg.begin(),i)
		<< "\nmsg substr:" << msg.substr( distance(msg.begin(),i), 2)
		<< endl;*/
	
	string key1 = "example";
	string key2 = "keyword";
	string msg = "help me obiwan kenobi";
	
	string ans = encode(msg, key1, key2);
	
	cout << "create_encoding:" << ans << endl;
	
	
	return 0;
}