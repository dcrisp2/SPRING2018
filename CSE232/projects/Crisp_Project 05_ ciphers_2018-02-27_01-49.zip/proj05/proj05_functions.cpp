#include<iostream>
using std::cout; using std::endl; using std::cin; using std::boolalpha; using std::ostream;

#include<string>
using std::string; using std::getline;

#include<vector>
using std::vector;

#include "proj05_functions.h"

string clean_string(string s){
    string s_clean;
    for (auto ele : s){
        if (ele <= 'Z' && ele >= 'A'){
            s_clean.push_back( ele-('Z'-'z') );
        } else if (ele <= 'z' && ele >= 'a'){
            s_clean.push_back(ele);
        }
    }
    return s_clean;
};

string create_encoding(string key){
    int indices[25] = {};
    string block;
    for (auto ele : key){
        if ( ele!='q' && ele>'q' && indices[ele-'a'-1]==0 ){
            block.push_back(ele);
            indices[ele-'a'-1]=1;
        }else if ( ele>='a' && ele<'q' && indices[ele-'a']==0){
            block.push_back(ele);
            indices[ele-'a']=1;
        }
    }
    
    for (int i = 0; i<25; i++){
        if(i+'a' < 'q' && indices[i]==0){
            block.push_back((char) (i+'a'));
        } else if (i+'a' >= 'q' && indices[i]==0){
            block.push_back((char) (i+'a'+1));
        }
    }
    
    return block;
};

string encode_digraph(string dg, string block1, string block2){
    string block = "abcdefghijklmnoprstuvwxyz";
    string out;
    int indx_1 = block.find(dg[0],0);
    int indx_2 = block.find(dg[1],0);
    
    out.push_back(block1[(indx_1/5)*5 + (indx_2%5)]);
    out.push_back(block2[(indx_2/5)*5 + (indx_1%5)]);
    
    return out;
};

string decode_digraph(string dg, string block1, string block2){
    string block = "abcdefghijklmnoprstuvwxyz";
    string out;
    int indx_1 = block1.find(dg[0],0);
    int indx_2 = block2.find(dg[1],0);
    
    out.push_back(block[(indx_1/5)*5 + (indx_2%5)]);
    out.push_back(block[(indx_2/5)*5 + (indx_1%5)]);
    
    return out;
};

string encode(string msg, string key1, string key2){
    //check that this is returning an even 'end' for even indexes
    msg = clean_string(msg);
    
    if (msg.length()%2 != 0){
        msg.push_back('x');
    }
    
    string enc_msg;
    string block1 = create_encoding(key1);
    //cout << "block1:" << block1 << endl;
    string block2 = create_encoding(key2);
    //cout << "block2:" << block2 << endl;
    
    
    for (std::string::iterator i=msg.begin(); i<msg.end(); i=i+2){
        string temp = encode_digraph( msg.substr( distance(msg.begin(),i) ,2), block1, block2 );
        //cout << "temp encoded:" << temp << endl;
        
        for (auto ele : temp){
            enc_msg.push_back(ele);
            //cout << "enc_msg:" << enc_msg << endl;
        }
    }
    
    return enc_msg;
};

string decode(string enc_msg, string key1, string key2){
    string dec_msg;
    string block1 = create_encoding(key1);
    string block2 = create_encoding(key2);
    
    for (std::string::iterator i=enc_msg.begin(); i<enc_msg.end(); i=i+2){
        string temp = decode_digraph( enc_msg.substr( distance(enc_msg.begin(),i) ,2), block1, block2 );
        //cout << "temp encoded:" << temp << endl;
        
        for (auto ele : temp){
            dec_msg.push_back(ele);
            //cout << "enc_msg:" << enc_msg << endl;
        }
    }
    
    return dec_msg;
};




