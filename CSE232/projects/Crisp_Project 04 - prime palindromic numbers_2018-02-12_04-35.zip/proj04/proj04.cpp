//AUTHOR:   Dan Crisp
//DATE:     11FEB2018
//SECTION:  CSE232 -- 730(online)
//TITLE:    proj04
/*description
    Identify 'palindromic prime' numbers in various bases
*/


#include<iostream>
using std::cout; using std::cin; using std::endl; using std::boolalpha;
#include<string>
using std::string; using std::to_string;
#include<cmath>
#include<utility>
using std::swap;

const string the_chars = "0123456789abcdef";

//returns the string argument 'str' in reverse order
string reverse_str(string str){
    int n = str.length();
 
    // Swap characters at edges and work inward
    for (int i=0; i<n/2; i++){
       swap(str[i], str[n-i-1]);
    }
    
    return str;
}

//returns true if argument 'str' is palindrome, false otherwise
bool is_palindrome(string str){
    if(str==reverse_str(str)){
        return true;
    } else {
        return false;
    }
}

//Converts the provided long into a string, where the string represent sthe long converted to the provided base.
string long_to_base(long n, long b){
    string str = "";
    int i = 0;
    
    while(n>0){
        str = the_chars[n%b] + str;
        n = n/b;
        i++;
    }
    
    return str;
}

//returns true if argument 'num' is prime, false otherwise
bool is_prime(long num){
    
    for(int i = 2; i<=sqrt(num); i++) {
        if(num%i==0){
            return false;
        }
    }
    return true;
}

//takes single long argument, returns one of the following 4 strings: binary-pal-prime, decimal-pal-prime, hex-pal-prime, or not-pal-prime
string is_pal_prime(long n){
    string str_base2 = long_to_base(n,2);
    string str_base10 = long_to_base(n,10);
    string str_base16 = long_to_base(n,16);
    
    if (is_prime(n) && is_palindrome(str_base2)){
        return "binary-pal-prime";
    } else if(is_prime(n) && is_palindrome(str_base10)){
        return "decimal-pal-prime";
    } else if(is_prime(n) && is_palindrome(str_base16)){
        return "hex-pal-prime";
    }
    
    return "not-pal-prime";
}



int main (){
  long test_num;
  cin >> test_num;
  cout << boolalpha;

  switch(test_num) {

  case 1: {
    string input;
    cin >> input;
    cout << reverse_str(input);
    break;
  }

  case 2:{
    string input;
    cin >> input;
    cout << is_palindrome(input);
    break;
  }

  case 3:{
    long n, base;
    cin >> n >> base;
    cout << long_to_base(n,base);
    break;
  }

  case 4:{
    long n;
    cin >> n;
    cout << is_prime(n);
    break;
  }

  case 5:{
    long n;
    cin >> n;
    cout << is_pal_prime(n);
    break;
  }
    
  } // of switch
}  // of main
  
