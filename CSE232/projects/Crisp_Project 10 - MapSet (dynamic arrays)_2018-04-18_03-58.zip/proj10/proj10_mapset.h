//NAME:     Dan Crisp
//CLASS:    CSE232, Section730
//DATE:     17APRIL2018
/*description
creating a templated class that duplicates the STL mapset class
*/

#ifndef MAP_SET
#define MAP_SET

#include<iostream>
using std::ostream; using std::cout; using std::endl;
#include<string>
using std::string;
#include<vector>
using std::vector;
#include<utility>
using std::pair;
#include<initializer_list>
using std::initializer_list;
#include<algorithm>
using std::sort; using std::lower_bound;
#include<sstream>
using std::ostringstream;


//
// Node
//
template<typename K, typename V>
struct Node {
  K first;
  V second;
  Node() = default;
  Node(K,V);
  bool operator<(const Node&) const;
  bool operator==(const Node&) const;
  friend ostream& operator<<(ostream &out, const Node &n){
    // WRITE YOUR CODE HERE!!!
    out << n.first << ":" << n.second;
    return out;
  }
};

template<typename K, typename V>
Node<K,V>::Node(K key, V value){
    first = key;
    second = value;
}

template<typename K, typename V>
bool Node<K,V>::operator<(const Node &n) const{
    if(first < n.first){
        return true;
    };
    return false;
}

template<typename K, typename V>
bool Node<K,V>::operator==(const Node &n) const{
    if(first == n.first){
        return true;
    };
    return false;
}

//
// MapSet
// 
template<typename K, typename V>
class MapSet{
 private:
  Node<K,V>* ary_;
  size_t last_;
  size_t capacity_;
  Node<K,V>* find_key(K);
  void grow ();
 public:
  MapSet(int sz = 2);
  MapSet(initializer_list< Node<K,V> >);
  MapSet (const MapSet&);
  MapSet operator=(MapSet);
  ~MapSet();
  size_t size();
  void swap (MapSet&, MapSet&);
  bool remove (K);  
  bool add(Node<K,V>);
  Node<K,V> get(K);
  bool update(K,V);  
  int compare(MapSet&);
  MapSet mapset_union (MapSet&);
  MapSet mapset_intersection(MapSet&);

  friend ostream& operator<<(ostream &out, const MapSet &ms){
    // WRITE YOUR CODE HERE!!!
    out << ms.ary_[0];
    for(size_t i = 1; i < ms.last_; ++i){
        out << ", " << ms.ary_[i];
    };
    return out;
  }  
};

//initialize MapSet as empty but with a given capacity
template<typename K, typename V>
MapSet<K,V>::MapSet(int capacity){
    capacity_ = capacity;
    last_ = 0;
    ary_ = new Node<K,V> [capacity_];
}

//initialize MapSet by passing it a list. Regardless of whether list is organized, MapSet will be ordered alphabatically by key.
template<typename K, typename V>
MapSet<K,V>::MapSet(initializer_list< Node<K,V> > list){
    last_ = 0;
    capacity_ = 2*list.size();
    ary_ = new Node<K,V> [capacity_];
    
    for(auto ele : list){
        add(ele);
    }
}

template<typename K, typename V>
MapSet<K,V>::MapSet(const MapSet &ms){
    last_ = ms.last_;
    capacity_ = ms.capacity_;
    ary_ = new Node<K,V>[capacity_];
    for(size_t i = 0; i < last_; ++i){
        ary_[i] = ms.ary_[i];//insert arg array into calling array.
    }
}

template<typename K, typename V>
void MapSet<K,V>::swap(MapSet &ms1, MapSet &ms2){
    std::swap (ms1.last_, ms2.last_);
    std::swap (ms1.capacity_, ms2.capacity_);
    std::swap (ms1.ary_, ms2.ary_);
}

// copy and swap
template<typename K, typename V>
MapSet<K,V> MapSet<K,V>::operator=(MapSet<K,V> ms){
    last_ = ms.size();
    capacity_ = ms.capacity_;
    swap(*this, ms);
    return *this;
}

template<typename K, typename V>
MapSet<K,V>::~MapSet(){
    delete [] ary_;
}

template<typename K, typename V>
size_t MapSet<K,V>::size(){
    return last_;
}

//doubles capacity of underlying array
template<typename K, typename V>
void MapSet<K,V>::grow(){
    Node<K,V>* new_ary = new Node<K,V> [capacity_*2];
    for(size_t i = 0; i < last_; ++i){
        new_ary[i] = ary_[i]; //insert old ary into new_ary w/ twice capacity
    }
    std::swap(new_ary, ary_);
    capacity_ = capacity_*2;
    delete[] new_ary;
}

//locate the location of the node in MapSet with a key that matches the find_key() argument 'key', return either the location of node with matching key, a nullptr, or the location of the first node who's key is lexicographically larger.
template<typename K, typename V>
Node<K,V>* MapSet<K,V>::find_key(K key){
    Node<K,V> n(key,NULL);
    auto ptr = lower_bound(ary_, ary_+last_, n);
    return ptr;
}

//IF the node argument passed to add() does not already exist, add it to the MapSet
template<typename K, typename V>
bool MapSet<K,V>::add(Node<K,V> n){
    auto ptr = this->find_key(n.first);

    auto pos = distance(ary_, ptr);

    if((*ptr).first != n.first || ptr==nullptr){
        last_ = last_+1;

        if(last_>=capacity_) this->grow();
        Node<K,V>* new_ary = new Node<K,V> [capacity_];
        
        copy(ary_,ary_+pos,new_ary);// copies ary into new_ary, within range [arg1, arg2)
        
        new_ary[pos] = n;
        
        copy(ary_+pos, ary_+last_, new_ary+pos+1);// copies ary into new_ary, within range [arg1, arg2)
            
        std::swap(new_ary,ary_);//Possible Error if MapSet last_==capacity_
        delete [] new_ary;
        
        return true;
    }
    
    return false;
}

//remove node with key matching function argument
template<typename K, typename V>
bool MapSet<K,V>::remove(K key){
    auto ptr = this->find_key(key);
    size_t pos = distance(ary_, ptr);
    if((*ptr).first==key){
        Node<K,V>* new_ary = new Node<K,V> [capacity_];
        if(pos==0){
            copy(ary_+1,ary_+last_,new_ary);
        }else{
            copy(ary_,ary_+pos,new_ary);
            if(pos!=last_) copy(ary_+pos+1, ary_+last_, new_ary+pos);
        }
        
        std::swap(new_ary,ary_);//Possible Error if MapSet last_==capacity_
        delete [] new_ary;
        
        last_ = last_-1;
        if(capacity_ )
        return true;
    }
    
    return false;
}

//return the MapSet Node who's key matches that of the get function argument 'key'
template<typename K, typename V>
Node<K,V> MapSet<K,V>::get(K key){
    auto ptr = this->find_key(key);
    if((*ptr).first == key){
        Node<K,V> node(key,(*ptr).second);
        return node;
    }
    Node<K,V> node("",0);
    return node;
}

//if function argument key is found in MapSet, replace the value in the found Node with function argument value
template<typename K, typename V>
bool MapSet<K,V>::update(K key, V value){
    auto ptr = this->find_key(key);
    if((*ptr).first==key){
        (*ptr).second = value;
        return true;
    }
    return false;
}

//compare two MapSets lexicographically, element by element. If the calling MapSet is greater, return 1. If the argument MapSet is greater, return -1. If all of the comparable pairs is equal but one MapSet is bigger (has more pairs), then the longer determines the return value (1 if the first is longer, -1 if the second)
template<typename K, typename V>
int MapSet<K,V>::compare(MapSet &ms){
    size_t callerSize = this->size();
    size_t argSize = ms.last_;
    
    if(callerSize >= argSize){
        auto callerPtr = ary_;
        for (auto argPtr = ms.ary_; argPtr < ms.ary_+ms.last_; ++argPtr){
            //cout << "callerItr, " << (*callerItr).first << ", and argItr, " << (*argItr).first << ", being compared in callerSize >= argSize." << endl;
            if((*callerPtr).first > (*argPtr).first){
                return 1;//the caller MapSet pair is larger lexicographically than the arg MapSet pair
            } else if ((*callerPtr).first < (*argPtr).first){
                return -1;//the caller MapSet pair is smaller lexicographically than the arg MapSet pair
            }
            callerPtr++;
        }
        
        if(callerSize==argSize) return 0;
        
        return 1;
    }else if(callerSize < argSize){
        auto argPtr = ms.ary_;
        for (auto callerPtr = ary_; callerPtr < ary_+last_; ++callerPtr){
            //cout << "callerItr, " << (*callerItr).first << ", and argItr, " << (*argItr).first << ", being compared in callerSize < argSize." << endl;
            if((*callerPtr).first > (*argPtr).first){
                return 1;//the caller MapSet pair is larger lexicographically than the arg MapSet pair
            } else if ((*callerPtr).first < (*argPtr).first){
                return -1;//the caller MapSet pair is smaller lexicographically than the arg MapSet pair
            }
            argPtr++;
        }
        
        return -1;
    }
    
    return 0;
}

//Return a new MapSet that is a union of the two MapSets being called. If the two MapSets have the same key but different values, then the key-value of the calling MapSet is the one that is used.
template<typename K, typename V>
MapSet<K,V> MapSet<K,V>::mapset_union(MapSet<K,V> &ms){
    MapSet<K,V> Ms;
    for(auto callPtr = ary_; callPtr < ary_+last_; ++callPtr){
        Ms.add(*callPtr);
    }
    
    for(auto argPtr = ms.ary_; argPtr < ms.ary_ + ms.last_; ++argPtr){
        Ms.add(*argPtr);
    }
    
    return Ms;
}

//return new MapSet with intersecting(i.e. equal/shared) keys only (taking value from calling arg)
template<typename K, typename V>
MapSet<K,V> MapSet<K,V>::mapset_intersection(MapSet<K,V> &ms){
    MapSet<K,V> Ms;
    
    for(auto callPtr = ary_; callPtr < ary_+last_; ++callPtr){
        K callKey = (*callPtr).first;
        
        if( (ms.get(callKey)).second ){
            Ms.add(*callPtr);
        }
    }
    
    for(auto argPtr = ms.ary_; argPtr < ms.ary_ + ms.last_; ++argPtr){
        K argKey = (*argPtr).first;
        
        if( (this->get(argKey)).second ){
            Ms.add(*argPtr);
        }
        
    }
    
    return Ms;
}

#endif
  