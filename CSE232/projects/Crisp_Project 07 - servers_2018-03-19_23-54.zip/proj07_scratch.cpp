#include <iostream>
using std::cout; using std::endl;
#include <fstream>
using std::ifstream;
#include <map>
#include <set>
#include <string>
using std::string;
#include <cstring>
using std::strtok;
#include <utility>
#include <vector>
#include <fstream>
using std::invalid_argument;
#include <sstream>
using std::ostringstream; using std::istringstream;

using ServerData = std::map<std::string, std::set<std::string>>;

using UserName = const std::string &;
using ServerName = const std::string &;

const int MAX_CHARS_PER_LINE = 100;
const char* INPUT_DELIMITER = " ";

int main(){
    //char line[MAX_CHARS_PER_LINE];
    
    ifstream fin;
    fin.open ("input.txt");
    if (!fin.good())
			throw invalid_argument("Invalid Filename");
    
    ServerData sd;
    
    
    
    
    string line, uname, action, server;
    
    while(getline(fin, line)){
        istringstream iss(line);
        iss >> uname;
        iss >> action;
        iss >> server;
        
        cout << uname << " " << action << " " << server << endl;
        
        if(server != "join" || server != "leave"){
            throw invalid_argument("Invalid Action");
        }
        
        if( sd.find(server) == sd.end()){
            sd.insert(server);
        }        
        
    }
    

    return 0;
};