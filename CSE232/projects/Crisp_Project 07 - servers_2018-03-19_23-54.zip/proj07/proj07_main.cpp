#include<string>
#include<iostream>
#include<set>
#include<sstream>
#include "proj07_functions.h"

int main(){
    
    /*ServerData sd = ParseServerData("input.txt");
    auto arctic_itr = sd.find("arctic");
    int arctic_total = (arctic_itr->second).size();
    //ASSERT_EQ(arctic_total, 4);
    auto baron_itr = sd.find("baron");
    int baron_total = (baron_itr->second).size();
    //ASSERT_EQ(baron_total, 7);
    BalanceServers(sd, "arctic","baron");
    arctic_itr = sd.find("arctic");
    arctic_total = (arctic_itr->second).size();
    baron_itr = sd.find("baron");
    baron_total = (baron_itr->second).size();
    //ASSERT_EQ(arctic_total, 6);
    //ASSERT_EQ(baron_total, 5);
    std::ostringstream oss;
    PrintAll(oss, sd);
    std::string out = oss.str();
    std::string result = "arctic : alice bob dhruv fedor jose lily\nbaron :     alice loki matus sonam thor\nrusty : alice gigi\n";
    //ASSERT_EQ(out,result);*/
    
    ServerData sd = ParseServerData("input.txt");
    auto arctic_itr = sd.find("arctic");
    int arctic_total = (arctic_itr->second).size();
    std::cout << "arctic total should be 4. It is: " << arctic_total << std::endl;
    //ASSERT_EQ(arctic_total, 4);
    auto baron_itr = sd.find("baron");
    int baron_total = (baron_itr->second).size();
    std::cout << "baron total should be 7. It is: " << baron_total << std::endl;
    //ASSERT_EQ(baron_total, 7);
    CleanAndBalance(sd);
    arctic_itr = sd.find("arctic");
    arctic_total = (arctic_itr->second).size();
    baron_itr = sd.find("baron");
    baron_total = (baron_itr->second).size();
    std::cout << "arctic total should still be 4. It is: " << arctic_total << std::endl;
    //ASSERT_EQ(arctic_total, 4);
    std::cout << "baron total should now be 4. It is: " << baron_total << std::endl;
    //ASSERT_EQ(baron_total, 4);
    std::ostringstream oss;
    PrintAll(oss, sd);
    std::string out = oss.str();
    std::string result = "arctic : alice fedor lily sonam\nbaron : bob gigi loki thor\nrusty : dhruv jose matus\n";
    std::cout << "\nresult should be:\n" << result << std::endl;
    std::cout << "\nresult actually is:\n" << out << std::endl;
    //ASSERT_EQ(out,result);


    return 0;
}