//NAME:     DAN CRISP
//DATE:     March19,2018
//TITLE:    project 7, servers
//CLASS:    Section 730
/*
using an input file of format <name> <join/leave> <server>...
provide functions that parse server data, and allow manipulation of it
*/

#include <iostream>
using std::cout; using std::endl;
#include <fstream>
using std::ifstream;
#include <sstream>
using std::ostringstream; using std::istringstream;

#include <map>
using std::map;
#include <set>
using std::set;
#include <utility>
#include <vector>
using std::vector;
#include <string>
using std::string;
#include <algorithm>
using std::find;
#include <iterator>

using std::invalid_argument;
using std::domain_error;

//HEADER FILE
#include "proj07_functions.h"


//SPECIAL CONSTRUCTS
using ServerData = std::map<std::string, std::set<std::string>>;
using UserName = const std::string &;
using ServerName = const std::string &;


/*
Parse file contents, and return a map object for server data.
*/
ServerData ParseServerData(const std::string &fname){
    ServerData data;
    string line, uname, action, sname;
    map<string, set<string>>::iterator iter;
    
    
    ifstream fin;
    fin.open (fname);
    if (!fin.good())
			throw invalid_argument("Invalid Filename");
    
    while(getline(fin, line)){
        istringstream iss(line);
        iss >> uname;
            UserName user = uname;
        iss >> action;
        iss >> sname;
            ServerName server = sname;
        
        iter = data.find(server);
        
        if(action != "join" && action != "leave"){
            throw domain_error("Invalid Action");
        }
        
        if( iter == data.end() && action == "join"){
            set<string> user_set = {user};
            data.insert({server, user_set});
        }
        
        if( iter != data.end() && action == "join"){
            (*iter).second.insert(user);
        }
        
        if( iter != data.end() && action == "leave"){
            (*iter).second.erase(user);
        }
    }
    return data;
};



void PrintAll(std::ostream &ostr, const ServerData &data){
    string str;
    
    //iterate through server data
    for(auto iter = data.begin(); iter != data.end(); iter++){
        str = str + (*iter).first + " : "; //start string for pair
        for(auto ele : (*iter).second){
            str = str + ele + " ";
        } // iterate through user set (second in pair)
        str = str.substr(0, str.size()-1); //remove last space
        str = str + "\n"; //add next line
    }
    ostr << str;
};


/* tries to connect a user to a server.
if server exists, it adds UserName
if server does not exist, it is created (added to data) and user is added to that data
both of these conditions returns true.
*/
bool AddConnection(ServerData &data, ServerName server, UserName user){
    auto iter = data.find(server);
    set<string> user_set = {user};
    
    if( iter==data.end() ){
        data.insert({server, user_set});
        return true;
    }
    if( iter!=data.end() ){
        
        if ((*iter).second.find(user) != (*iter).second.end() ){
            return false;
        }
        
        (*iter).second.insert(user);
        return true;
    }
    return false;
};

/* tries to delete user from server set
returns true if user removed from server
returns false otherwise
*/
bool DeleteConnection(ServerData &data, ServerName server, UserName user){
    auto iter = data.find(server);
    
    if( iter == data.end() || (*iter).second.find(user) == (*iter).second.end() ){
        return false;
    } else {
        (*iter).second.erase(user);
        return true;
    }
};


//return all servers in server data
std::set<std::string> AllServers(const ServerData &data){
    set<string> servers;
    
    for (auto iter = data.begin(); iter != data.end(); iter++){
        servers.insert( (*iter).first );
    }
    return servers;
};


//return all connected users in server data
std::set<std::string> AllUsers(const ServerData &data){
    set<string> users;
    
    for (auto iter = data.begin(); iter != data.end(); iter++){
        set<string> temp = (*iter).second;
        for (auto iter2 = temp.begin(); iter2 != temp.end(); iter2++ ){
            users.insert( (*iter2) );
        }
    }
    return users;
};


//return all servers a given user is connected to
std::set<std::string> HasConnections(const ServerData &data, UserName user){
    set<string> connections;
    
    for (auto iter = data.begin(); iter != data.end(); iter++){
        if ((*iter).second.find(user) != (*iter).second.end() ){
            connections.insert((*iter).first);
        }
    }    
    return connections;
};


//return all users connected to a given server
std::set<std::string> HasUsers(const ServerData &data, ServerName server){
    set<string> connected;
    auto iter = data.find(server);
    
    //string the_server = (*iter).first;
    //cout << "server: " << the_server << ": ";
    
    if (iter != data.end() ){
        set<string> temp = (*iter).second;
        for (auto iter2 = temp.begin(); iter2 != temp.end(); iter2++){
            //cout << (*iter2) << " ";
            connected.insert( (*iter2) );
        }
        //cout << "\n";
    }
    return connected;
};


/*
attempts to balance number of users connected to server sn1 & sn2
If user connected to both servers, they are not moved
Users are sorted alphabetically by name, first half moved to server sn1, other half to server sn2.
if there's an odd number 'N' of users, N/2 + 1 are moved to sn1
*/
void BalanceServers(ServerData &data, ServerName sn1, ServerName sn2){
    set<string> sn1_users = HasUsers(data, sn1);
    set<string> sn2_users = HasUsers(data, sn2);
    
    set<string> N_users;
    N_users.insert(sn1_users.begin(), sn1_users.end());
    N_users.insert(sn2_users.begin(), sn2_users.end());
    
    for (auto iter = N_users.begin(); iter != N_users.end(); iter++){
        string user = (*iter);//iterating through set of all users
        
        bool in_sn1 = false;
        bool in_sn2 = false;
        
        //to simplify the following conditions, create 
        if (sn1_users.find( user ) != sn1_users.end() )
            in_sn1 = true;
        if (sn2_users.find( user ) != sn2_users.end() )
            in_sn2 = true;
            
        if ( in_sn1 && in_sn2 ){
            N_users.erase( user );
        } else if (in_sn1 && !in_sn2){
            DeleteConnection(data, sn1, user);
        } else if (!in_sn1 && in_sn2){
            DeleteConnection(data, sn2, user);
        }
        
        in_sn1 = false;
        in_sn2 = false;
    }
    
    auto N_range = (N_users.size());
    auto N_half = N_range/2;
    
    auto lim = N_half;
    if (N_users.size()%2 != 0){
        lim += 1;
    }
    
    auto iter = N_users.begin();
    for(unsigned int i = 0; i != N_range; i++ ){
        string user = (*iter);
        if (i < lim){
            AddConnection(data, sn1, user );
        } else {
            AddConnection(data, sn2, user );
        }
        iter++;
    }
    
};


/*removes all duplicate users from data.
unique users are moved around in following fasion:
    1.  all users and server names are sorted alphabetically
    2.  users are distributed to servers in round-robin fashion in alphabetical order of server and user names
    i.e. servers(x,y,z) and users(a,b,c,d,e,f,g,h). users(a,d,g) moved to server(x), users(b,e,h) moved to server(y), users(c,f) moved to server(z)
*/
void CleanAndBalance(ServerData &data){
    set<string> all_users = AllUsers(data);
    set<string> all_servers = AllServers(data);
    
    auto iter_servers = all_servers.begin();
    for ( auto iter_users = all_users.begin(); iter_users != all_users.end(); iter_users++){
        
        if(iter_servers == all_servers.end()) iter_servers = all_servers.begin();//while looping through users, if at end of server list, start again at beginning.
        
        //remove users from all existing connections
        set<string> connections = HasConnections(data, (*iter_users));
        for(auto i : connections){
            DeleteConnection(data, i, (*iter_users));
        }
        
        //add user to appropriate server for balancing
        AddConnection(data, (*iter_servers), (*iter_users));
        iter_servers++;
    }
};
