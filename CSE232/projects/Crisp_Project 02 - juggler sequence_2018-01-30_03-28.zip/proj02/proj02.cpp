//AUTHOR    :   DAN CRISP
//DATE      :   22JAN2018
//WEEK      :   3
//FILE      :   proj02.cpp
/*
    Juggler Sequence!

    input variables and output result of the juggler sequence
*/


#include <iostream>
#include <cmath>

using std::pow;
using std::floor;
using std::cin;
using std::cout;
using std::endl;

int main() {
    
    //INSTANTIATE VARS
    long input[3];
    long i, j(1);
    int cnt(1);
    long max[3] = {0, 0, 1};
    
    //INPUT
    cin >> input[0] >> input[1] >> input[2];
        
    //PROCESS
    if (input[0] > input[1] || input[0] < 2 || input[1] < 2 ) {
        cout << "Error" << endl;
        return 0;
    } else {
        while (input[0] <= input[1]) {
            if (input[2] == 1) {cout << input[0] << ": ";};
            i = input[0];
            
            while (i != 1) {
                if (i%2 == 0) {
                    i = floor( pow(i,(1.0/2)) );
                } else {
                    i = floor( pow(i,(3.0/2)) );
                }
                
                if (input[2] == 1) {cout << i;};
                
                if (i != 1){
                    if (input[2] == 1) {cout << ",";};
                    cnt = cnt+1;
                    if (j<i) { j = i; };
                } else {
                    if (max[1] < cnt) {
                        max[0] = input[0];
                        max[1] = cnt;
                        max[2] = j;
                        
                    }
                    cnt = 1;
                }
            }
            
            
            if (input[2] == 1) {cout << endl;};
            input[0]=input[0]+1;
        }
        
        cout << max[0] << ", " << max[1] << endl;
        cout << max[0] << ", " << max[2] << endl;
    }
    
    return 0;
}