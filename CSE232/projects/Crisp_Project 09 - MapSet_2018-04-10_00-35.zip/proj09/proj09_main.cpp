#include<iostream>
using std::cout; using std::endl; using std::boolalpha;
#include<sstream>
using std::ostringstream;
#include<string>
using std::string;
#include<utility>
using std::pair;
#include<initializer_list>
using std::initializer_list;

#include "proj09_mapset.h"

int main (){
  pair<string,long> itr;
  cout << boolalpha;
  
  MapSet ms ({ {"bill", 1}, {"fred", 2}, {"alan", 3}, {"bob", 4} });
  cout << "Size should be 4" << endl;
  cout << "Size:"<<ms.size() << endl << endl;

  MapSet ms_copy(ms);
  
  cout << "MapSet is..." << endl;
  cout << "ms:" << ms << endl;
  cout << "add ed: " << ms.add({"ed", 5}) << endl;
  cout << "add bob: " << ms.add({"bob", 5}) << endl;
  cout << "ms: "<< ms << endl;
  
  cout << "bob update:" << ms.update("bob", 100) << endl;
  cout <<  "george update:" << ms.update("george", 10) << endl;
  cout << "ms: "<< ms << endl;
  cout << "ms_copy: " << ms_copy << endl;

  cout << "remove fred from ms_copy: " << ms_copy.remove("fred") << endl;
  cout << "remove george from ms_copy: " << ms_copy.remove("george") << endl;  

  cout << "ms:"<< ms << endl;  
  cout << "copy:"<< ms_copy << endl;

  cout << "copy2ms: "<< ms_copy.compare(ms) << endl;
  cout << "ms2copy: "<<ms.compare(ms_copy) << endl;
  cout << "ms2ms: "<<ms.compare(ms) << endl;
  
  auto union_ms = ms.mapset_union(ms_copy);
  cout << "union: " <<union_ms << endl;
  auto intersect_ms = ms.mapset_intersection(ms_copy);
  cout << "intersection: "<< intersect_ms <<endl;
  
  //********************************************//
  /*MapSet ms1({ {"bill",1},{"alan",2},{"abby",3} });
  MapSet ms2({ {"alan",4},{"abby", 5},{"john",7} });
  MapSet ms3({ {"abby",5}, {"alan",17} });
  
  cout << endl << endl << "ms1: "<< ms1 << endl;
  cout << "ms2: "<< ms2 << endl;
  MapSet ms_union = ms1.mapset_union(ms2);
  cout << "ms_union: "<< ms_union << endl << endl;
  ostringstream oss;
  oss << ms_union;
  string result1 = oss.str();
  cout << "result1:\t" << result1 << endl;
  string ans1 = "abby:3, alan:2, bill:1, john:7";
  cout << "ans1:\t\t" << ans1 << endl << endl << endl;
  //ASSERT_EQ(result1, ans1);
  
  cout << "ms2: "<< ms2 << endl;
  cout << "ms1: "<< ms1 << endl;
  ms_union = ms2.mapset_union(ms1);
  cout << "ms_union: "<< ms_union << endl << endl;
  oss.str("");
  oss << ms_union;
  string result2 = oss.str();
  cout << "result2:\t" << result2 << endl;
  string ans2 = "abby:5, alan:4, bill:1, john:7";
  cout << "ans2:\t\t" << ans2 << endl << endl << endl;
  //ASSERT_EQ(ans2,result2);*/
  //********************************************//
  
  /*MapSet ms1({ {"bill",1},{"alan",2},{"abby",3} });
  MapSet ms2({ {"alan",4},{"abby", 5},{"john",7} });
  MapSet ms3({ {"abby",5}, {"alan",17} });
  
  cout << endl << endl << "ms1: "<< ms1 << endl;
  cout << "ms2: "<< ms2 << endl;  
  MapSet ms_intersect = ms1.mapset_intersection(ms2);
  ostringstream oss;
  oss << ms_intersect;
  string result1 = oss.str();
  cout << "result1:\t" << result1 << endl;
  string ans1 = "abby:3, alan:2";
  cout << "ans1:\t\t" << ans1 << endl << endl << endl;
  //ASSERT_EQ(result1, ans1);
  
  oss.str("");
  cout << "ms2: "<< ms2 << endl;
  cout << "ms1: "<< ms1 << endl;  
  ms_intersect = ms2.mapset_intersection(ms1);
  oss << ms_intersect;
  string result2 = oss.str();
  cout << "result2:\t" << result2 << endl;
  string ans2 = "abby:5, alan:4";
  cout << "ans2:\t\t" << ans2 << endl << endl << endl;*/
  //ASSERT_EQ(result2, ans2);
  //********************************************//  
  
  /*MapSet Ms({ {"bill",1},{"alan",2},{"abby",3} });
  
  cout << endl << endl << Ms << endl;
  auto bool_result = Ms.remove("bill");
  cout << "bool for removing bill: " << bool_result << endl;
  cout << Ms << endl;
  auto pr = Ms.get("bill");
  string key = pr.first; string key_ans = "";
  cout << endl << "Key gotten from Ms.get(\"bill\").first: " << key << endl;
  cout << "Key_ans: " << key_ans << endl;
  //ASSERT_EQ(key, key_ans);
  //ASSERT_TRUE(bool_result);
    
  bool_result = Ms.remove("irving");
  cout << endl << "Bool for removing irving: " << bool_result << endl;
  //ASSERT_FALSE(bool_result);
  ostringstream oss;
  oss << Ms;
  string ans = "abby:3, alan:2";
  string str_result = oss.str();
  cout << endl << endl << "ans: " << ans << endl;
  cout << "str_result: " << str_result << endl << endl;*/
  //ASSERT_EQ(ans, str_result);
  
  cout << endl << endl << "TROUBLESHOOTING MapSet::compare..." << endl;
  MapSet ms1({ {"bill",1},{"alan",2},{"abby",3} });
  MapSet ms2({ {"alan",2},{"abby", 3},{"john",4} });
  MapSet ms3({ {"abby",5}, {"alan",17} });
  cout << "Our MapSets being compared..." << endl;
  cout << "ms1: " << ms1 << endl;
  cout << "ms2: " << ms2 << endl;
  cout << "ms3: " << ms3 << endl << endl;


  int result1 = ms1.compare(ms2);
  int ans1 = -1;
  cout << "result1, ms1.compare(ms2): " << result1 << endl;
  cout << "ans1: " << ans1 << endl << endl;
  //ASSERT_EQ(result1,ans1);
  int result2 = ms2.compare(ms1);
  int ans2 = 1;
  cout << "result2, ms2.compare(ms1): " << result2 << endl;
  cout << "ans2: " << ans2 << endl << endl;
  //ASSERT_EQ(result2,ans2);
  int result3 = ms1.compare(ms1);
  int ans3 = 0;
  cout << "result3, ms1.compare(ms1): " << result3 << endl;
  cout << "ans3: " << ans3 << endl << endl;
  //ASSERT_EQ(result3,ans3);
  int result4 = ms1.compare(ms3);
  int ans4 = 1;
  cout << "result4, ms1.compare(ms3): " << result4 << endl;
  cout << "ans4: " << ans4 << endl << endl;
  //ASSERT_EQ(result4, ans4);
  int result5 = ms3.compare(ms1);
  int ans5 = -1;
  cout << "result5, ms3.compare(ms1): " << result5 << endl;
  cout << "ans5: " << ans5 << endl << endl;
  //ASSERT_EQ(result5, ans5);
  
}
  