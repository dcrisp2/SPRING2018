//NAME:     Daniel Crisp
//DATE:     9APRIL2018
//CLASS:    CSE232: Section730
/* description
write a mapset program using vector< pair<string, long> >
including get, add, compare, union, intersection functions
*/

#include<iostream>
using std::cout; using std::endl; using std::ostream; using std::ostringstream;
#include<string>
using std::string;
#include<vector>
using std::vector;
#include<utility>
using std::pair;
#include<initializer_list>
using std::initializer_list;
#include<algorithm>
using std::lower_bound;

#include "proj09_mapset.h"

//returns pointer to first pair in v_ that is NOT smaller than the string argument, OR v_.end()
vector< pair <string, long> >::iterator MapSet::find_key(string str){
    auto itr =  lower_bound(v_.begin(),
                            v_.end(),
                            str, 
                            [] (pair<string,long> p1, string key) {
                                return (p1.first < key);
                            }
                );

    return itr;
};

//add pair to MapSet.v_ if string in pair does not already exist
bool MapSet::add(pair<string,long> p){
    auto itr = this->find_key(p.first);
    if(itr==v_.end() || (*itr).first != p.first){
        v_.insert(itr, p);
        return true;
    }
    
    return false;
}

MapSet::MapSet(initializer_list< pair<string,long> > il){
    for(auto ele : il){
        this->add(ele);
    }
}

size_t MapSet::size(){
    size_t sz(0);
    for(auto p : v_){
        sz++;
        //cout << "p: " << p.first << " " << p.second << endl;
    }
    
    return sz;
}

//returns a pair<string,long> that is either a copy of the pair that has the string as a key or a pair with default values (that is, a pair<string,long> with the value {"",0})
pair<string,long> MapSet::get(string str){
    auto itr = this->find_key(str);
    //try (*itr).first != str... instead of itr==v_.end()
    if((*itr).first != str || itr==v_.end()){
        return pair<string, long> {"",0};
    }
    
    return *itr;
}

bool MapSet::update(string str,long n){
    auto itr = this->find_key(str);
    //try (*itr).first == str instead of itr!=v_.end()
    if((*itr).first==str){
        (*itr).second = n;
        return true;
    }
    
    return false;
}

bool MapSet::remove(string str){
    auto itr = this->find_key(str);
    if((*itr).first == str){
        v_.erase(itr);
        return true;
    }
    
    return false;
}

//compare two MapSets lexicographically, element by element. If the calling MapSet is greater, return 1. If the argument MapSet is greater, return -1. If all of the comparable pairs is equal but one MapSet is bigger (has more pairs), then the longer determines the return value (1 if the first is longer, -1 if the second)
int MapSet::compare(MapSet& ms){
    size_t callerSize = this->size(); //maybe try placing this at the end of the function?
    size_t argSize = ms.size();
    if(callerSize >= argSize){ //IF caller MapSet longer than arg MapSet then...
        auto callerItr = v_.begin();
        for (auto argItr = ms.v_.begin(); argItr < ms.v_.end(); ++argItr){
            //cout << "callerItr, " << (*callerItr).first << ", and argItr, " << (*argItr).first << ", being compared in callerSize >= argSize." << endl;
            if((*callerItr).first > (*argItr).first){
                //cout << "callerItr, " << (*callerItr).first << ", greater than argItr, " << (*argItr).first << endl;
                return 1;//the caller MapSet pair is larger lexicographically than the arg MapSet pair
            } else if ((*callerItr).first < (*argItr).first){
                //cout << "callerItr, " << (*callerItr).first << ", less than argItr, " << (*argItr).first << endl;
                return -1;//the caller MapSet pair is smaller lexicographically than the arg MapSet pair
            }
            callerItr++;
        }
        
        if(callerSize==argSize) return 0;//where the pair keys are equal, AND there's the same number of pairs in each
        return 1;//where the pair keys are equal but caller MapSet is longer than arg MapSet
    } else if (callerSize < argSize){
        auto argItr = ms.v_.begin();
        for (auto callerItr = v_.begin(); callerItr < v_.end(); ++callerItr){
            //cout << "callerItr, " << (*callerItr).first << ", and argItr, " << (*argItr).first << ", being compared in callerSize < argSize." << endl;
            if((*callerItr).first > (*argItr).first){
                //cout << "callerItr, " << (*callerItr).first << ", greater than argItr, " << (*argItr).first << endl;
                return 1;//the caller MapSet pair is larger lexicographically than the arg MapSet pair
            } else if ((*callerItr).first < (*argItr).first){
                //cout << "callerItr, " << (*callerItr).first << ", less than argItr, " << (*argItr).first << endl;
                return -1;//the caller MapSet pair is smaller lexicographically than the arg MapSet pair
            }
            argItr++;
        }
        
        return -1;
    }
    
    return 0;
}

//Return a new MapSet that is a union of the two MapSets being called. If the two MapSets have the same key but different values, then the key-value of the calling MapSet is the one that is used.
MapSet MapSet::mapset_union (MapSet& argMs){
    MapSet Ms;
    for(auto callItr = v_.begin(); callItr < v_.end(); ++callItr){
        Ms.add(*callItr);
    }
    
    for(auto argItr = argMs.v_.begin(); argItr < argMs.v_.end(); ++argItr){
        Ms.add(*argItr);
    }
    
    return Ms;
}

//return new MapSet with intersecting(i.e. equal/shared) keys only (taking value from calling arg)
MapSet MapSet::mapset_intersection(MapSet& argMs){
    MapSet Ms;
    for(auto callItr = v_.begin(); callItr < v_.end(); ++callItr){
        string callStr = (*callItr).first; //get callIter key(str)
        //if string from calling MapSet is found in arg MapSet, add it to result
        //doing call MapSet first gives its value priority
        if( (argMs.get(callStr)).second ){
            Ms.add(*callItr);
        }
    }
    
    for(auto argItr = argMs.v_.begin(); argItr < argMs.v_.end(); ++argItr){
        string argStr = (*argItr).first; //for easier reading
        //if string from arg MapSet is found in call MapSet, add it to result (if already exists, add will do nothing)
        if( (this->get(argStr)).second ){
            Ms.add(*argItr);
        }
    }
    
    return Ms;
}

//friend function allowing 'out << ms'
ostream & operator<<(ostream& out, MapSet& ms){
    int isFirst(1);
    for (auto pair : ms.v_){
        if(isFirst){
            out << pair.first << ":" << pair.second;
            isFirst = 0;
        } else {
            out << ", " << pair.first << ":" << pair.second;
        }
    }
    
    return out;
}
