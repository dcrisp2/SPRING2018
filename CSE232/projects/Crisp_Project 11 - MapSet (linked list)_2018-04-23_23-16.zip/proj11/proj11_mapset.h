//NAME:     Dan Crisp
//DATE:     23APRIL2018
//CLASS:    CSE232, Section 730
/*description
writing a single linked list

*/


#ifndef MAP_SET
#define MAP_SET

#include<iostream>
using std::ostream; using std::cout; using std::endl;
#include<string>
using std::string;
#include<utility>
using std::pair;
#include<initializer_list>
using std::initializer_list;
#include<sstream>
using std::ostringstream;


//
// Node
//
template<typename K, typename V>
struct Node {
    K first;
    V second;
    Node *next = nullptr;
  
    Node() = default;
    Node(K,V);
    bool operator<(const Node&) const;
    bool operator==(const Node&) const;
    friend ostream& operator<<(ostream &out, const Node &n){
        out << n.first << ":" << n.second;
        return out;
    }
};

template<typename K, typename V>
Node<K,V>::Node(K key, V value){
    first = key;
    second = value;
}

template<typename K, typename V>
bool Node<K,V>::operator<(const Node &n) const{
    if(first < n.first){
        return true;
    }
    return false;
}

template<typename K, typename V>
bool Node<K,V>::operator==(const Node &n) const{
    if(first == n.first){
        return true;
    }
    return false;
}


//
// MapSet
// 
template<typename K, typename V>
class MapSet{
    private:
        Node<K,V>* head_ = nullptr;
        Node<K,V>* tail_ = nullptr;  
        size_t sz_ = 0;
        Node<K,V>* find_key(K);

    public:
        MapSet()=default;
        MapSet(initializer_list< Node<K,V> >);
        MapSet (const MapSet&);
        MapSet operator=(MapSet);
        ~MapSet();
        size_t size();
        bool remove (K);  
        bool add(Node<K,V>);
        Node<K,V> get(K);
        bool update(K,V);  
        int compare(MapSet&);
        MapSet mapset_union (MapSet&);
        MapSet mapset_intersection(MapSet&);

        friend ostream& operator<<(ostream &out, const MapSet &ms){
            ostringstream oss;
            Node<K,V>* node = ms.head_;
    
            while(node!=nullptr){
        
                oss << *node << ", ";
                node = (*node).next;
            }
    
            string s = oss.str();
            out << s.substr(0,s.size()-2);
            return out;
        }  
};

//initialize mapset with a list
template<typename K, typename V>
MapSet<K,V>::MapSet(initializer_list< Node<K,V> > list){
    for(auto node : list){
        add(node);
    }
}

//copy mapset to calling mapset
template<typename K, typename V>
MapSet<K,V>::MapSet(const MapSet &ms){
    Node<K,V>* node;
    for(node = ms.head_; node != nullptr; node = (*node).next){
        add(*node);
    }
}

//assign arg mapset to calling mapset
template<typename K, typename V>
MapSet<K,V> MapSet<K,V>::operator=(MapSet ms){
    std::swap (head_, ms.head_);
    std::swap (tail_, ms.tail_);
    std::swap (sz_, ms.sz_);
    
    return *this;
}	

// walk down the list, moving head_ but remember it in to_del
// delete each node in turn, the set head_ and tail_
template<typename K, typename V>
MapSet<K,V>::~MapSet(){
    Node<K,V>* to_del = head_;
    while (to_del != nullptr){
        head_ = (*head_).next;
        delete to_del;
        to_del = head_;
    }
    head_ = nullptr;
    tail_ = nullptr;
}

//return private var, sz_
template<typename K, typename V>
size_t MapSet<K,V>::size(){
    return sz_;
}

//return a pointer to the node that matches key, has a key that is greater lexicographically than the argument, or nullptr
template<typename K, typename V>
Node<K,V>* MapSet<K,V>::find_key(K key){
    Node<K,V> *node_ptr;
    //cout << endl << "Looking for key: " << key << endl;
    for(node_ptr = head_; node_ptr != nullptr; node_ptr = (*node_ptr).next){
        if( (*node_ptr).first >= key ){
            //cout << "find_key() seems to have found a greater or equal key..." << endl;
            return node_ptr;
        }
    }
    
    //cout << "find_key() is likely passing nullptr..." << endl;
    return node_ptr;
}

//add node given as argument in alphabetically sorted MapSet, do not add if a node with the same key already exists
template<typename K, typename V>
bool MapSet<K,V>::add(Node<K,V> n){
    Node<K,V>* found_node = this->find_key(n.first);
    //cout << "Inside add(), after calling find_key()..." << endl;
    if( found_node && (*found_node).first == n.first ) return false;
    
    Node<K,V>* arg_node = new Node<K,V>(n.first, n.second);
    
    //if node is not found, find_key returns nullptr
    if( !found_node && sz_==0){
        head_ = arg_node;
        tail_ = arg_node;
        sz_ = 1;
        return true;
    }else if(!found_node){
        (*tail_).next = arg_node;
        tail_ = arg_node;
        sz_ = sz_ + 1;
        return true;
    }
    
    //if found node is first in list
    if( found_node == head_ && (*head_).first != (*arg_node).first){
        tail_ = head_;
        head_ = arg_node;
        (*head_).next = tail_;
        sz_ = sz_ + 1;
        return true;
    }
    
    //if node with greater key value is returned, should work if it finds last node too
    for(Node<K,V>* node = head_; node != found_node; node = (*node).next){
        
        //when node points to a node whose next value needs to be pushed back, set (*node).next = n, 
        if( (*node).next == found_node ){
            (*arg_node).next = found_node;
            (*node).next = arg_node;
            sz_ = sz_ + 1;
            return true;
        }
    }
    
    return false;
}

//remove the node with a key that matches the one passed via argument
template<typename K, typename V>
bool MapSet<K,V>::remove(K key){
    Node<K,V>* node;
    
    for(node = head_; node != nullptr; node = (*node).next){
        //if node.first == key at head, remove, and reset head
        //if node.next.first == key, not tail, remove, and reset next
        //if node.next.first == key, at tail, remove, and reset tail
        if( (*node).next == nullptr && (*node).first != key) return false;
        
        if( (*(*node).next).first == key ){
            
            if( (*node).next == tail_ ){
                tail_ = node;
                delete (*node).next;
            } else {
                Node<K,V>* temp = (*(*node).next).next;
                delete (*node).next;
                (*node).next = temp;
            }
            return true;
        } else if( (*node).first == key ){
            head_ = (*node).next;
            delete node;
            return true;    
        }
    }
    return false;
}

//return the node that has a key matching that passed as an argument
template<typename K, typename V>
Node<K,V> MapSet<K,V>::get(K key){
    Node<K,V>* found_node = this->find_key(key);
    
    if( found_node && (*found_node).first == key ){
        return *found_node;
    };
    Node<K,V>* default_node = new Node<K,V>("", 0);
    return *default_node;
}

//update the value in the node with a key matching what's sent in the argument
template<typename K, typename V>
bool MapSet<K,V>::update(K key, V value){
    Node<K,V>* node = this->find_key(key);
    
    if( node && (*node).first == key ){
        (*node).second = value;
        return true;
    }
    
    return false;
}


template<typename K, typename V>
int MapSet<K,V>::compare(MapSet &ms){
    size_t callerSize = sz_;
    size_t argSize = ms.sz_;
    
    //make sure that you iterate through the smaller mapset so you don't go over index
    if(callerSize >= argSize){
        auto callerPtr = head_;
        for (auto argPtr = ms.head_; argPtr != nullptr; argPtr = (*argPtr).next){
            if((*callerPtr).first > (*argPtr).first){
                return 1;//the caller MapSet pair is larger lexicographically than the arg MapSet pair
            } else if ((*callerPtr).first < (*argPtr).first){
                return -1;//the caller MapSet pair is smaller lexicographically than the arg MapSet pair
            }
            callerPtr = (*callerPtr).next;
        }
        
        if(callerSize==argSize) return 0;
        
        return 1;
    }else if(callerSize < argSize){
        auto argPtr = ms.head_;
        for (auto callerPtr = head_; callerPtr != nullptr; callerPtr = (*callerPtr).next){
            if((*callerPtr).first > (*argPtr).first){
                return 1;//the caller MapSet pair is larger lexicographically than the arg MapSet pair
            } else if ((*callerPtr).first < (*argPtr).first){
                return -1;//the caller MapSet pair is smaller lexicographically than the arg MapSet pair
            }
            argPtr = (*argPtr).next;
        }
        
        return -1;
    }
    
    return 0;
}

//return mapset comprised of all nodes in both calling and argument mapsets, BUT no duplicates, prioritizing values in argument mapset.
template<typename K, typename V>
MapSet<K,V> MapSet<K,V>::mapset_union(MapSet<K,V> &argMs){
    MapSet<K,V> newMs;
    
    for(auto callNode = head_; callNode != nullptr; callNode = (*callNode).next){
        newMs.add(*callNode);
    }
    
    for(auto argNode = argMs.head_; argNode != nullptr; argNode = (*argNode).next){
        newMs.add(*argNode);
    }
    
    return newMs;
}

//return a MapSet comprised only of nodes that exist in both argument and calling mapsets
template<typename K, typename V>
MapSet<K,V> MapSet<K,V>::mapset_intersection(MapSet<K,V> &argMs){
    MapSet<K,V> newMs;
    
    for(auto callNode = head_; callNode != nullptr; callNode = (*callNode).next){
        K callKey = (*callNode).first;
        
        if( (argMs.get(callKey)).second ){
            newMs.add(*callNode);
        }
    }
    
    for(auto argNode = argMs.head_; argNode != nullptr; argNode = (*argNode).next){
        K argKey = (*argNode).first;
        
        if( (this->get(argKey)).second ){
            newMs.add(*argNode);
        }
    }
    
    return newMs;
}

#endif
  