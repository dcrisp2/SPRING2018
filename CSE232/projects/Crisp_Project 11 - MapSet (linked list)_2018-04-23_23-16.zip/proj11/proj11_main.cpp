#include<iostream>
using std::cout; using std::endl; using std::boolalpha;
#include<string>
using std::string;
#include<sstream>
using std::ostringstream;

#include "proj11_mapset.h"

int main (){
    
    /*
    MapSet<string,long> ms;
    bool bool_result;
    string str_result;
    bool_result = ms.add({"bill", 1});
    cout << "ms.add() bill:1... should be true..." << bool_result << endl;
    //ASSERT_TRUE(bool_result);
    bool_result = ms.add({"bill", 2});
    cout << "ms.add() bill:2... should be false..." << bool_result << endl;
    bool_result = ms.add({"alan", 2});
    cout << "ms.add() alan:2... should be true..." << bool_result << endl;
    //ASSERT_TRUE(bool_result);
    bool_result = ms.add({"fred", 3});
    cout << "ms.add() fred:3... should be true..." << bool_result << endl;
    //ASSERT_TRUE(bool_result);
    ostringstream oss;
    oss << ms;
    str_result = oss.str();
    string ans="alan:2, bill:1, fred:3";
    cout << "str_result: " << str_result << endl;
    cout << "ans: " << ans << endl;
    //ASSERT_EQ(str_result,ans);
    */
    
    /*
    MapSet<string,long> ms({ {"bill",1},{"alan",2},{"abby",3} });

    auto pr = ms.get("bill");
    string key = pr.first; string key_ans = "bill";
    long val = pr.second; long val_ans = 1;
    cout << endl << "key: " << key << ", and key_ans: " << key_ans << endl;
    //ASSERT_EQ(key, key_ans);
    cout << endl << "val: " << val << ", and val_ans: " << val_ans << endl;
    //ASSERT_EQ(val, val_ans);
    
    pr = ms.get("irving");
    key = pr.first; key_ans = "";
    val = pr.second; val_ans = 0;
    cout << endl << "key: " << key << ", and key_ans: " << key_ans << endl;
    //ASSERT_EQ(key, key_ans);
    cout << endl << "val: " << val << ", and val_ans: " << val_ans << endl;
    //ASSERT_EQ(val, val_ans);
    */
    
    
    /*
    MapSet<string,long> ms({ {"bill",1},{"alan",2},{"abby",3} });

    auto bool_result = ms.update("bill",4);
    auto pr = ms.get("bill");
    long val = pr.second; long val_ans = 4;
    cout << endl << "val: " << val << ", and val_ans: " << val_ans << endl;
    //ASSERT_EQ(val, val_ans);
    cout << "ms.update() bill:4... should be true..." << bool_result << endl;
    //ASSERT_TRUE(bool_result);
    
    bool_result = ms.update("irving", 10);
    pr = ms.get("irving");
    val = pr.second; val_ans = 0;
    cout << endl << "val: " << val << ", and val_ans: " << val_ans << endl;
    //ASSERT_EQ(val, val_ans);
    cout << "ms.update() irving:10... should be false..." << bool_result << endl;
    //ASSERT_FALSE(bool_result);
    */
    
    /*
    MapSet<string,long> ms({ {"bill",1},{"alan",2},{"abby",3} });

    auto bool_result = ms.remove("bill");
    auto pr = ms.get("bill");
    string key = pr.first; string key_ans = "";
    cout << endl << "key: " << key << ", and key_ans: " << key_ans << endl;
    //ASSERT_EQ(key, key_ans);
    cout << "ms.remove() bill... should be true..." << bool_result << endl;
    //ASSERT_TRUE(bool_result);
    
    bool_result = ms.remove("irving");
    cout << "ms.remove() irving... should be false..." << bool_result << endl;
    //ASSERT_FALSE(bool_result);
    ostringstream oss;
    oss << ms;
    string ans = "abby:3, alan:2";
    string str_result = oss.str();
    cout << "ans: " << ans << ", and str_result: " << str_result << endl;
    //ASSERT_EQ(ans, str_result);
    */
    
    MapSet<string,long> ms1({ {"bill",1},{"alan",2},{"abby",3} });
    MapSet<string, long> ms2({ {"alan",4},{"abby", 5},{"john",7} });
    MapSet<string, long> ms3({ {"abby",5}, {"alan",17} });
    cout << endl << "ms1: " << ms1 << endl << "ms2: " << ms2 << endl << "ms3: " << ms3 <<  endl << endl;
    
    
    cout << "ms1.mapset_union(ms2)..." << endl;
    MapSet<string,long> ms_union = ms1.mapset_union(ms2);
    ostringstream oss;
    oss << ms_union;
    string result1 = oss.str();
    string ans1 = "abby:3, alan:2, bill:1, john:7";
    cout << "result1: " << result1 << endl << "ans1: " << ans1 << endl << endl;
    //ASSERT_EQ(result1, ans1);
    
    cout << "ms2.mapset_union(ms1)..." << endl;
    //MapSet<string,long> ms_union2 = ms2.mapset_union(ms1);
    ms_union = ms2.mapset_union(ms1);
    oss.str("");
    oss << ms_union;
    string result2 = oss.str();
    
    //cout << "this is oss.str(): " << oss.str() << endl;
    string ans2 = "abby:5, alan:4, bill:1, john:7";
    cout << "result2: " << result2 << endl << "ans2: " << ans2 << endl;
    //ASSERT_EQ(ans2,result2);
}
