//AUTHOR    :   DAN CRISP
//DATE      :   21JAN2018
//WEEK      :   3
//FILE      :   proj01.cpp
/*
    Buying a car!

    input variables and calculate the monthly payment
*/


#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

int main() {
    cout << fixed << setprecision(2);
    
    //system("cls");
    
    // VARIABLES
    double price;
    double tax;
    double down_pmt;
    double title_and_fees;
    double APR;
    double MPR;
    double loan_duration;
    double monthly_payment;
    
    // INPUT
    cin >> price;
    cin >> tax;
    cin >> down_pmt;
    cin >> title_and_fees;
    cin >> APR;
    MPR = APR/12;
    cin >> loan_duration;
    
    double cost = (price*(1+tax))+title_and_fees-down_pmt;
    double mpr_pow = pow((1+MPR),loan_duration);
    //PROCESS
    monthly_payment = (cost) * 
        (
            ( MPR*mpr_pow )
            /( mpr_pow -1 )
        );
    
    cout << monthly_payment;
    
    
    
    
    
    
    
    return 0;
}
