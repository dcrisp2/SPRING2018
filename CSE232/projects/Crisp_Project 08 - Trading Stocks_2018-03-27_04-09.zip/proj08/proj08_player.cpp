//NAME:     DANIEL CRISP
//DATE:     26MARCH, 2018
//SECTION:  CSE232, sect. 730

#include <iostream>
using std::cout; using std::endl;
#include<sstream>
using std::ostringstream;
#include<iomanip>
#include<map>
using std::map;
#include<vector>
using std::vector;
#include<string>
using std::string;
#include<utility>
using std::pair;
#include <set>
using std::set;
#include<iterator>
#include<cmath>


#include "proj08_market.h"
#include "proj08_player.h"

//Player::Player(double c) : cash(c) {} ;

//buy a given quantity of stocks on a given date, using the given market data as reference. reflect the necessary changes for the given player
bool Player::buy(Market &m, string stock, long date, long quantity){
    double cost;
    cost = m.get_price(stock, date) * quantity;
    
    //if(cost > 0 && cash >= cost && m.stocks.find(date) != m.stocks.end()){
    if(cost > 0 && cash >= cost){
        cash -= cost;
        //cout << "cost: " << cost << "$" << endl;
        stocks[stock] += quantity;
        //cout << "stock value owned: " << stocks[stock] << "$" << endl;
        
        return true;
    }
    
    return false;
};


//sell a given quantity of stocks on a given date, using the given market data as reference. reflect the necessary changes for the given player.
bool Player::sell(Market &m, string stock, long date, long quantity){
    double cost;
    cost = m.get_price(stock, date) * quantity;
    
    //if(stocks.find(stock) != stocks.end() && cost > 0 && cost <= (*stocks.find(stock)).second){
    if(stocks.find(stock) != stocks.end() && cost > 0 && stocks[stock] >= quantity){
        cash += cost;
        stocks[stock] -= quantity;
        
        return true;
    }
    
    return false;
};

//returns a string representation of the player... 'cash,symbol:quantity,symbol:quantity...'
string Player::to_str(){
    ostringstream oss;
    
    oss << std::setprecision(2) << std::fixed << cash;
    
    for(auto iter : stocks){
        oss << "," << iter.first << ":" << iter.second;
    }
    
    return oss.str();
};


Player Player::combine(Player& b){
    Player c;
    
    //add their cash values, then remove those values from this player and player b
    c.cash = cash + b.cash;
    cash = 0;
    b.cash = 0;
    
    //c.stocks = this->stocks;
    //this->stocks = 0;
    for (auto iter : this->stocks ){
        c.stocks[iter.first] += iter.second;
        iter.second = 0;
    }
    this->stocks.clear();
    
    for (auto iter : b.stocks ){
        c.stocks[iter.first] += iter.second;
        iter.second = 0;
    }
    b.stocks.clear();
    
    return c;
};