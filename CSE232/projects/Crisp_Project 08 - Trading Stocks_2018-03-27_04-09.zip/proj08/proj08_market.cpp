//NAME:     DANIEL CRISP
//DATE:     26MARCH, 2018
//SECTION:  CSE232, sect. 730

#include<map>
using std::map;
#include<vector>
using std::vector;
#include<string>
using std::string;
#include<utility>
using std::pair;
#include <iterator>
#include <algorithm>
using std::find;
#include <set>
using std::set;

#include <iostream>
using std::cout; using std::endl;
#include <sstream>
using std::ostringstream; using std::istringstream;
#include <iostream>
using std::cout; using std::endl;
#include <fstream>
using std::ifstream;

using std::invalid_argument;


#include "proj08_market.h"
#include "proj08_player.h"

//set filename with string input. parse file and populate market mapping
Market::Market(string s){
    file_name = s;
    
    string line;
    long date;
    double price;
    
    ifstream fin;
    fin.open (file_name);
    
    if (!fin.good())
			throw invalid_argument("Invalid Filename");
    
    while(getline(fin, line)){
        
        istringstream iss(line);
        iss >> date;
        
        vector<double> price_vector;
        while(iss >> price){
            price_vector.push_back(price);
        }
        
        stocks.insert({date, price_vector});
    }
};

//return price of a stock with the given stock symbol and date
double Market::get_price(string stock, long date) const
{
    double price;
    auto dateInStocks_iter = stocks.find(date);
    auto stockInList_iter = find(symbol_list.begin(), symbol_list.end(), stock);
    
    //if date is in stock data, and stock symbol is recognized, find price of that stock for that date
    if( dateInStocks_iter != stocks.end() &&
        stockInList_iter != symbol_list.end()){
        
        auto pos = distance(symbol_list.begin(), stockInList_iter);
        auto stockIter = dateInStocks_iter;
        
        price = (*stockIter).second.at(pos);
        
        return price;
    }
    
    return -1.0;
};

//return the highest, and lowest prices for a given stock in the given year
pair<double, double> Market::high_low_year(long year, string symbol){
    pair<double, double> p;
    string year_str = std::to_string(year);
    //set<double> prices;
    vector<double> prices;
    
    p = std::make_pair(-1.0, -1.0); //default, if provided year can't be found in map, {-1.0, -1.0} gets returned.
    
    for(auto iter : stocks){
        long date = iter.first;
        
        if(date/10000 == year){
            auto price = this->get_price(symbol, date);
            //prices.insert(price);
            prices.push_back(price);
            
            std::sort(prices.begin(), prices.end());
            //p = std::make_pair(*prices.begin(), *prices.end());
            p = std::make_pair(prices.back(), prices.front());
        }
    }
    
    return p;
};



