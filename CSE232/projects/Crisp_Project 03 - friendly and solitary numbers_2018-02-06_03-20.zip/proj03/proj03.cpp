//AUTHOR:   Dan Crisp
//DATE:     5FEB2018
//SECTION:  CSE232 -- 730(online)
//TITLE:    proj03
/*description
    Friendly vs Solitary numbers.
    tests functions that find:
        divisor sum of a numbers
        greatest common denominator shared between two numbers
        a boolean state for whether a number is Solitary
        string for information about friendly numbers

**NOTE** code for gcd function essentially copied from https://en.wikipedia.org/wiki/Euclidean_algorithm#Implementations
*/

#include<iostream>
using std::cout; using std::cin; using std::endl; using std::boolalpha;
#include<cmath>
#include<string>
using std::to_string; using std::string;

string abIndex_friend(long ab_numerator, long ab_denominator, long f_pair){
  return to_string(ab_numerator) + "/" + to_string(ab_denominator) +
    ":" + to_string(f_pair);
}

//divisor_sum returns the sum of all proper divisors of input number
long divisor_sum(long num){
    long sum = 0;
    int i = 1;
    while ( i <= floor(sqrt(num)) ) {
        if (num%i==0) {
            sum += i + (num/i);
        }
        i++;
    }
    return sum;
}

//gcd finds greatest common denominator of input numbers a and b
long gcd(long a, long b){
    int t;
    while (b != 0){
        t = b;
        b = a%b;
        a = t;
    }
    return a;
}

//is_solitatry returns boolean value depending on whether input number has any proper divisors
bool is_solitary(long num){
    if (gcd(divisor_sum(num), num) == 1){
        return true;
    } else {
        return false;
    }
}

//friendly_check finds any friendly numbers between the input number and an upper limit, it then returns the abundance of the input number and either the found friendly number or a '-1'
string friendly_check(int num, int limit){
    //instantiate abundance numerator/denominator, and their greatest common denominator
    long ab_numerator = divisor_sum(num);
    long ab_denominator = num;
    long comm_denom = gcd(ab_numerator, ab_denominator);
    
    //reduce abundance numerator/denominator
    ab_numerator = ab_numerator/comm_denom;
    ab_denominator = ab_denominator/comm_denom;
    
    
    long i_num, i_denom, i_comm_denom;
    
    for (long i = num + 1; i <= limit; i++ ){
        i_num = divisor_sum(i);
        i_denom = i;
        i_comm_denom = gcd(i_num, i_denom);
        
        i_num = i_num/i_comm_denom;
        i_denom = i_denom/i_comm_denom;
        
        //compare abundance numerator & denominator of num var with that of i, and return values if equal
        if (ab_numerator == i_num && ab_denominator == i_denom){
            return abIndex_friend(ab_numerator, ab_denominator, i);
        }
    }
    return abIndex_friend(ab_numerator, ab_denominator, -1);
}

int main (){
  cout << boolalpha;   // print true or false for bools
  int test;
  cin >> test;
  switch (test) {
  case 1 : {   // divisor sum test
    long input;
    cin >> input;
    cout << divisor_sum(input) << endl;
    break;
  } // of case 1

  case 2:{    // gcd test
    long first, second;
    cin >> first >> second;
    cout << gcd(first, second) << endl;
    break;
  } // of case 2

  case 3: {    // is_solitary test
    long input;
    cin >> input;
    cout << is_solitary(input) << endl;
    break;
  } // of case 3

  case 4: {
    // friend check. Make sure the return value is the
    // result of calling abIndex_friend, a string!
    long input, limit;
    cin >> input >> limit;
    cout << friendly_check(input, limit) << endl;
    break;
  } // of case 4
    
  } // of switch
} // of main
