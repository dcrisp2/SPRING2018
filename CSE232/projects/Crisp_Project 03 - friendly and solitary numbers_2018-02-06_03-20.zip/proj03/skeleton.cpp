//AUTHOR:   Dan Crisp
//DATE:     5FEB2018
//SECTION:  CSE232 -- 730(online)
//TITLE:    proj03
/*description
    Friendly vs Solitary numbers.
    tests functions that find:
        divisor sum of a numbers
        greatest common denominator shared between two numbers
        a boolean state for whether a number is Solitary
        string for information about friendly numbers
*/

#include<iostream>
using std::cout; using std::cin; using std::endl; using std::boolalpha;
#include<cmath>
#include<string>
using std::to_string; using std::string;

string abIndex_friend(long ab_numerator, long ab_denominator, long f_pair){
  return to_string(ab_numerator) + "/" + to_string(ab_denominator) +
    ":" + to_string(f_pair);
}

// YOUR FUNCTIONS HERE
long divisor_sum(long num){
    long sum = 0;
    int i = 1;
    while ( i <= num) {
        if (num%i==0) {
            sum += i;
        }
        i++;
    }
    return sum;
}

long gcd(long a, long b){
    int t;
    while (b != 0){
        t = b;
        b = a%b;
        a = t;
    }
    return a;
}

bool is_solitary(long num){
    if (gcd(divisor_sum(num), num) == 1){
        return true;
    } else {
        return false;
    }
}

string friendly_check(int num, int limit){
    long ab_numerator = divisor_sum(num);
    long ab_denominator = num;
    long comm_denom = gcd(ab_numerator, ab_denominator);
    
    ab_numerator = ab_numerator/comm_denom;
    ab_denominator = ab_denominator/comm_denom;
    
    long i_num, i_denom;
    
    for (long i = 2; i <= limit; i++ ){
        //i_num = divisor_sum(i) / gcd(divisor_sum(i), i);
        //i_denom = i / gcd(divisor_sum(i), i);
        
        i_num = divisor_sum(i);
        i_denom = i;
        
        if (ab_numerator == i_num && ab_denominator == i_denom){
            return abIndex_friend(ab_numerator, ab_denominator, i);
        }
    }
    
    return abIndex_friend(ab_numerator, ab_denominator, -1);
}

int main (){
  cout << boolalpha;   // print true or false for bools
  int test;
  cin >> test;
  switch (test) {
  case 1 : {   // divisor sum test
    long input;
    cin >> input;
    cout << divisor_sum(input) << endl;
    break;
  } // of case 1

  case 2:{    // gcd test
    long first, second;
    cin >> first >> second;
    cout << gcd(first, second) << endl;
    break;
  } // of case 2

  case 3: {    // is_solitary test
    long input;
    cin >> input;
    cout << is_solitary(input) << endl;
    break;
  } // of case 3

  case 4: {
    // friend check. Make sure the return value is the
    // result of calling abIndex_friend, a string!
    long input, limit;
    cin >> input >> limit;
    cout << friendly_check(input, limit) << endl;
    break;
  } // of case 4
    
  } // of switch
} // of main
